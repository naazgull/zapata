#pragma once

#include <parsers/JSONTokenizerLexer.h>

#define JScanner public: JSONTokenizerLexer
namespace zapata {
}

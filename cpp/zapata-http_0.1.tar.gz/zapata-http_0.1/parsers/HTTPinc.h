#pragma once

#include <zapata/core.h>
#include <http/HTTPObj.h>
#include <parsers/HTTPTokenizerLexer.h>

#define Scanner public: HTTPTokenizerLexer
namespace zapata {
}
